# 🪵 الرحبي للنجارة — Flutter App

نظام إدارة محلات النجارة — تطبيق Flutter احترافي متعدد المنصات

---

## 📱 المميزات

| الميزة | الوصف |
|--------|-------|
| 🔐 المصادقة | تسجيل دخول + إنشاء حساب + جلسات دائمة |
| 🏪 اختيار المحل | دعم multi-tenant كامل |
| 👥 إدارة العملاء | أعمال + مدفوعات + قياسات |
| 👷 إدارة العمال | أجور + سحوبات + بوابة العامل |
| 🏭 إدارة الموردين | مشتريات + مدفوعات |
| 💰 التدفق النقدي | تقرير مالي شامل |
| 🤖 محلل AI | تحليل مشاريع النجارة بالذكاء الاصطناعي |
| ☁️ Firebase | مزامنة حقيقية + دعم بدون إنترنت |

---

## 🚀 خطوات الإعداد

### 1. المتطلبات

- Flutter SDK 3.2.0+
- Dart 3.2.0+
- Android Studio / Xcode
- Firebase project (موجود بالفعل)

### 2. تثبيت التبعيات

```bash
flutter pub get
```

### 3. إعداد Firebase

#### Android
1. افتح [Firebase Console](https://console.firebase.google.com)
2. اختر مشروع `mahali-app-8bd6a`
3. أضف تطبيق Android بـ Package Name: `com.rahbi.carpentry`
4. حمّل `google-services.json` وضعه في `android/app/`

#### iOS
1. أضف تطبيق iOS بـ Bundle ID: `com.rahbi.carpentry`
2. حمّل `GoogleService-Info.plist` وضعه في `ios/Runner/`

### 4. تشغيل التطبيق

```bash
# Android
flutter run

# iOS
flutter run -d ios

# Web
flutter run -d chrome
```

---

## 🗂️ هيكل المشروع

```
lib/
├── main.dart                    # نقطة الدخول
├── firebase_options.dart        # إعدادات Firebase
├── core/
│   ├── theme.dart              # نظام التصميم (ألوان، خطوط، أحجام)
│   ├── providers.dart          # Riverpod state management
│   └── app_router.dart         # GoRouter navigation
├── models/
│   └── models.dart             # كل data models
├── screens/
│   ├── splash_screen.dart
│   ├── auth_screen.dart
│   ├── shop_select_screen.dart
│   ├── main_shell.dart         # Bottom nav shell
│   ├── dashboard_screen.dart
│   ├── clients_screen.dart     # + ClientDetailScreen
│   ├── workers_screen.dart     # + WorkerDetailScreen
│   ├── suppliers_screen.dart   # + SupplierDetailScreen
│   ├── ai_analyzer_screen.dart
│   ├── cashflow_screen.dart
│   ├── settings_screen.dart
│   └── worker_portal_screen.dart
└── widgets/
    └── common_widgets.dart     # مكونات مشتركة
```

---

## 🔑 إعداد محلل AI

في شاشة `محلل AI`، اضغط على أيقونة المفتاح ⚙️ في الأعلى وأدخل مفتاح Anthropic API الخاص بك.

للحصول على مفتاح API: [console.anthropic.com](https://console.anthropic.com)

---

## 📦 بناء APK للرفع

```bash
# APK عادي
flutter build apk --release

# App Bundle لـ Google Play
flutter build appbundle --release
```

---

## 🔧 إضافة خطوط Cairo وTajawal

ضع ملفات الخطوط في مجلد `assets/fonts/`:

- Cairo-Regular.ttf
- Cairo-Medium.ttf
- Cairo-SemiBold.ttf
- Cairo-Bold.ttf
- Cairo-ExtraBold.ttf
- Tajawal-Regular.ttf
- Tajawal-Medium.ttf
- Tajawal-Bold.ttf
- Tajawal-ExtraBold.ttf
- Tajawal-Black.ttf

يمكن تحميلها من [Google Fonts](https://fonts.google.com/specimen/Cairo)

---

## 🏗️ الإصدار

**v1.4.0** — مطابق لـ mahali-v14-full

---

## 📞 الدعم

راجع المشروع الأصلي PWA للمرجع الكامل.
