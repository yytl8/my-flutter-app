import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

// ══════════════════════════════════════════
// 🔥 إعدادات Firebase — مشروع mahali-347c7
// تم التوليد من google-services.json
// ══════════════════════════════════════════
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        return android;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDnxbUAFergmjU8YWSuZZlKlypejPA0kys',
    authDomain: 'mahali-347c7.firebaseapp.com',
    projectId: 'mahali-347c7',
    storageBucket: 'mahali-347c7.firebasestorage.app',
    messagingSenderId: '276652722828',
    appId: '1:276652722828:web:REPLACE_WITH_WEB_APP_ID',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDnxbUAFergmjU8YWSuZZlKlypejPA0kys',
    appId: '1:276652722828:android:7a9ea7c9854e57201649a9',
    messagingSenderId: '276652722828',
    projectId: 'mahali-347c7',
    storageBucket: 'mahali-347c7.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDnxbUAFergmjU8YWSuZZlKlypejPA0kys',
    appId: '1:276652722828:ios:REPLACE_WITH_IOS_APP_ID',
    messagingSenderId: '276652722828',
    projectId: 'mahali-347c7',
    storageBucket: 'mahali-347c7.firebasestorage.app',
    iosBundleId: 'com.mahali.app',
  );
}
