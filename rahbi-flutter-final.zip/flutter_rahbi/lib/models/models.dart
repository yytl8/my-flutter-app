import 'package:cloud_firestore/cloud_firestore.dart';

// ══════════════════════════════════════════
// 👤 User Model
// ══════════════════════════════════════════
class AppUser {
  final String id;
  final String name;
  final String email;
  final String role; // 'superadmin' | 'admin' | 'worker'
  final String? shopId;
  final String? phone;
  final String? avatar;
  final DateTime? createdAt;
  final Map<String, bool> permissions;

  const AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.shopId,
    this.phone,
    this.avatar,
    this.createdAt,
    this.permissions = const {},
  });

  bool get isAdmin => role == 'admin' || role == 'superadmin';
  bool get isSuperAdmin => role == 'superadmin';
  bool get isWorker => role == 'worker';

  factory AppUser.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AppUser(
      id: doc.id,
      name: data['name'] ?? '',
      email: data['email'] ?? '',
      role: data['role'] ?? 'worker',
      shopId: data['shopId'],
      phone: data['phone'],
      avatar: data['avatar'],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      permissions: Map<String, bool>.from(data['permissions'] ?? {}),
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'email': email,
    'role': role,
    'shopId': shopId,
    'phone': phone,
    'avatar': avatar,
    'permissions': permissions,
    'updatedAt': FieldValue.serverTimestamp(),
  };
}

// ══════════════════════════════════════════
// 🏪 Shop Model
// ══════════════════════════════════════════
class Shop {
  final String id;
  final String name;
  final String? ownerId;
  final String? phone;
  final String? address;
  final String? logo;
  final bool isActive;
  final DateTime? createdAt;

  const Shop({
    required this.id,
    required this.name,
    this.ownerId,
    this.phone,
    this.address,
    this.logo,
    this.isActive = true,
    this.createdAt,
  });

  factory Shop.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Shop(
      id: doc.id,
      name: data['name'] ?? '',
      ownerId: data['ownerId'],
      phone: data['phone'],
      address: data['address'],
      logo: data['logo'],
      isActive: data['isActive'] ?? true,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'ownerId': ownerId,
    'phone': phone,
    'address': address,
    'logo': logo,
    'isActive': isActive,
    'updatedAt': FieldValue.serverTimestamp(),
  };
}

// ══════════════════════════════════════════
// 👥 Client Model
// ══════════════════════════════════════════
class Client {
  final String id;
  final String shopId;
  final String name;
  final String? phone;
  final String? address;
  final String? notes;
  final DateTime? createdAt;

  const Client({
    required this.id,
    required this.shopId,
    required this.name,
    this.phone,
    this.address,
    this.notes,
    this.createdAt,
  });

  factory Client.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Client(
      id: doc.id,
      shopId: data['shopId'] ?? '',
      name: data['name'] ?? '',
      phone: data['phone'],
      address: data['address'],
      notes: data['notes'],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
    'shopId': shopId,
    'name': name,
    'phone': phone,
    'address': address,
    'notes': notes,
    'updatedAt': FieldValue.serverTimestamp(),
  };
}

// ══════════════════════════════════════════
// 🔨 Work (Project) Model
// ══════════════════════════════════════════
class Work {
  final String id;
  final String shopId;
  final String clientId;
  final String clientName;
  final String title;
  final String? description;
  final String status; // 'pending' | 'inProgress' | 'done' | 'delivered'
  final double totalAmount;
  final double paidAmount;
  final List<WorkPayment> payments;
  final List<WorkMeasurement> measurements;
  final DateTime? startDate;
  final DateTime? endDate;
  final DateTime? createdAt;

  const Work({
    required this.id,
    required this.shopId,
    required this.clientId,
    required this.clientName,
    required this.title,
    this.description,
    this.status = 'pending',
    this.totalAmount = 0,
    this.paidAmount = 0,
    this.payments = const [],
    this.measurements = const [],
    this.startDate,
    this.endDate,
    this.createdAt,
  });

  double get remaining => totalAmount - paidAmount;
  double get progressPct => totalAmount > 0 ? (paidAmount / totalAmount).clamp(0.0, 1.0) : 0.0;

  String get statusLabel {
    switch (status) {
      case 'pending': return 'قيد الانتظار';
      case 'inProgress': return 'جاري التنفيذ';
      case 'done': return 'منتهي';
      case 'delivered': return 'تم التسليم';
      default: return status;
    }
  }

  factory Work.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Work(
      id: doc.id,
      shopId: data['shopId'] ?? '',
      clientId: data['clientId'] ?? '',
      clientName: data['clientName'] ?? '',
      title: data['title'] ?? '',
      description: data['description'],
      status: data['status'] ?? 'pending',
      totalAmount: (data['totalAmount'] ?? 0).toDouble(),
      paidAmount: (data['paidAmount'] ?? 0).toDouble(),
      payments: (data['payments'] as List<dynamic>? ?? [])
          .map((p) => WorkPayment.fromMap(p as Map<String, dynamic>))
          .toList(),
      measurements: (data['measurements'] as List<dynamic>? ?? [])
          .map((m) => WorkMeasurement.fromMap(m as Map<String, dynamic>))
          .toList(),
      startDate: (data['startDate'] as Timestamp?)?.toDate(),
      endDate: (data['endDate'] as Timestamp?)?.toDate(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
    'shopId': shopId,
    'clientId': clientId,
    'clientName': clientName,
    'title': title,
    'description': description,
    'status': status,
    'totalAmount': totalAmount,
    'paidAmount': paidAmount,
    'payments': payments.map((p) => p.toMap()).toList(),
    'measurements': measurements.map((m) => m.toMap()).toList(),
    'startDate': startDate != null ? Timestamp.fromDate(startDate!) : null,
    'endDate': endDate != null ? Timestamp.fromDate(endDate!) : null,
    'updatedAt': FieldValue.serverTimestamp(),
  };
}

class WorkPayment {
  final String id;
  final double amount;
  final String? note;
  final String date;

  const WorkPayment({
    required this.id,
    required this.amount,
    this.note,
    required this.date,
  });

  factory WorkPayment.fromMap(Map<String, dynamic> m) => WorkPayment(
    id: m['id'] ?? '',
    amount: (m['amount'] ?? 0).toDouble(),
    note: m['note'],
    date: m['date'] ?? '',
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'amount': amount,
    'note': note,
    'date': date,
  };
}

class WorkMeasurement {
  final String id;
  final String item;
  final String? width;
  final String? height;
  final String? depth;
  final String? notes;
  final String date;

  const WorkMeasurement({
    required this.id,
    required this.item,
    this.width,
    this.height,
    this.depth,
    this.notes,
    required this.date,
  });

  factory WorkMeasurement.fromMap(Map<String, dynamic> m) => WorkMeasurement(
    id: m['id'] ?? '',
    item: m['item'] ?? '',
    width: m['width'],
    height: m['height'],
    depth: m['depth'],
    notes: m['notes'],
    date: m['date'] ?? '',
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'item': item,
    'width': width,
    'height': height,
    'depth': depth,
    'notes': notes,
    'date': date,
  };
}

// ══════════════════════════════════════════
// 👷 Worker Model
// ══════════════════════════════════════════
class Worker {
  final String id;
  final String shopId;
  final String name;
  final String? phone;
  final String? specialty;
  final double dailyRate;
  final List<WorkerWithdrawal> withdrawals;
  final List<WorkerJob> jobs;
  final DateTime? joinDate;
  final DateTime? createdAt;
  final Map<String, bool> permissions;

  const Worker({
    required this.id,
    required this.shopId,
    required this.name,
    this.phone,
    this.specialty,
    this.dailyRate = 0,
    this.withdrawals = const [],
    this.jobs = const [],
    this.joinDate,
    this.createdAt,
    this.permissions = const {},
  });

  double get totalEarned => jobs.fold(0, (s, j) => s + j.amount);
  double get totalWithdrawn => withdrawals.fold(0, (s, w) => s + w.amount);
  double get balance => totalEarned - totalWithdrawn;

  factory Worker.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Worker(
      id: doc.id,
      shopId: data['shopId'] ?? '',
      name: data['name'] ?? '',
      phone: data['phone'],
      specialty: data['specialty'],
      dailyRate: (data['dailyRate'] ?? 0).toDouble(),
      withdrawals: (data['withdrawals'] as List<dynamic>? ?? [])
          .map((w) => WorkerWithdrawal.fromMap(w as Map<String, dynamic>))
          .toList(),
      jobs: (data['jobs'] as List<dynamic>? ?? [])
          .map((j) => WorkerJob.fromMap(j as Map<String, dynamic>))
          .toList(),
      joinDate: (data['joinDate'] as Timestamp?)?.toDate(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      permissions: Map<String, bool>.from(data['permissions'] ?? {}),
    );
  }

  Map<String, dynamic> toMap() => {
    'shopId': shopId,
    'name': name,
    'phone': phone,
    'specialty': specialty,
    'dailyRate': dailyRate,
    'withdrawals': withdrawals.map((w) => w.toMap()).toList(),
    'jobs': jobs.map((j) => j.toMap()).toList(),
    'joinDate': joinDate != null ? Timestamp.fromDate(joinDate!) : null,
    'permissions': permissions,
    'updatedAt': FieldValue.serverTimestamp(),
  };
}

class WorkerWithdrawal {
  final String id;
  final double amount;
  final String? note;
  final String date;
  final String status; // 'approved' | 'pending' | 'rejected'

  const WorkerWithdrawal({
    required this.id,
    required this.amount,
    this.note,
    required this.date,
    this.status = 'approved',
  });

  factory WorkerWithdrawal.fromMap(Map<String, dynamic> m) => WorkerWithdrawal(
    id: m['id'] ?? '',
    amount: (m['amount'] ?? 0).toDouble(),
    note: m['note'],
    date: m['date'] ?? '',
    status: m['status'] ?? 'approved',
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'amount': amount,
    'note': note,
    'date': date,
    'status': status,
  };
}

class WorkerJob {
  final String id;
  final String title;
  final double amount;
  final String date;
  final String status; // 'approved' | 'pending'
  final String? notes;

  const WorkerJob({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    this.status = 'pending',
    this.notes,
  });

  factory WorkerJob.fromMap(Map<String, dynamic> m) => WorkerJob(
    id: m['id'] ?? '',
    title: m['title'] ?? '',
    amount: (m['amount'] ?? 0).toDouble(),
    date: m['date'] ?? '',
    status: m['status'] ?? 'pending',
    notes: m['notes'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'amount': amount,
    'date': date,
    'status': status,
    'notes': notes,
  };
}

// ══════════════════════════════════════════
// 🏭 Supplier Model
// ══════════════════════════════════════════
class Supplier {
  final String id;
  final String shopId;
  final String name;
  final String? phone;
  final String? goodsType;
  final String? address;
  final List<SupplierPurchase> purchases;
  final List<SupplierPayment> payments;
  final DateTime? createdAt;

  const Supplier({
    required this.id,
    required this.shopId,
    required this.name,
    this.phone,
    this.goodsType,
    this.address,
    this.purchases = const [],
    this.payments = const [],
    this.createdAt,
  });

  double get totalPurchases => purchases.fold(0, (s, p) => s + p.amount);
  double get totalPaid => payments.fold(0, (s, p) => s + p.amount);
  double get remaining => totalPurchases - totalPaid;

  factory Supplier.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Supplier(
      id: doc.id,
      shopId: data['shopId'] ?? '',
      name: data['name'] ?? '',
      phone: data['phone'],
      goodsType: data['goodsType'],
      address: data['address'],
      purchases: (data['purchases'] as List<dynamic>? ?? [])
          .map((p) => SupplierPurchase.fromMap(p as Map<String, dynamic>))
          .toList(),
      payments: (data['payments'] as List<dynamic>? ?? [])
          .map((p) => SupplierPayment.fromMap(p as Map<String, dynamic>))
          .toList(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
    'shopId': shopId,
    'name': name,
    'phone': phone,
    'goodsType': goodsType,
    'address': address,
    'purchases': purchases.map((p) => p.toMap()).toList(),
    'payments': payments.map((p) => p.toMap()).toList(),
    'updatedAt': FieldValue.serverTimestamp(),
  };
}

class SupplierPurchase {
  final String id;
  final double amount;
  final String? item;
  final String? note;
  final String date;

  const SupplierPurchase({
    required this.id,
    required this.amount,
    this.item,
    this.note,
    required this.date,
  });

  factory SupplierPurchase.fromMap(Map<String, dynamic> m) => SupplierPurchase(
    id: m['id'] ?? '',
    amount: (m['amount'] ?? 0).toDouble(),
    item: m['item'],
    note: m['note'],
    date: m['date'] ?? '',
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'amount': amount,
    'item': item,
    'note': note,
    'date': date,
  };
}

class SupplierPayment {
  final String id;
  final double amount;
  final String? note;
  final String date;

  const SupplierPayment({
    required this.id,
    required this.amount,
    this.note,
    required this.date,
  });

  factory SupplierPayment.fromMap(Map<String, dynamic> m) => SupplierPayment(
    id: m['id'] ?? '',
    amount: (m['amount'] ?? 0).toDouble(),
    note: m['note'],
    date: m['date'] ?? '',
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'amount': amount,
    'note': note,
    'date': date,
  };
}
