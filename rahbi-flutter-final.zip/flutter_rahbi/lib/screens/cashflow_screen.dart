import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../widgets/common_widgets.dart';

class CashflowScreen extends ConsumerWidget {
  const CashflowScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final worksAsync = ref.watch(worksProvider);
    final workersAsync = ref.watch(workersProvider);
    final suppliersAsync = ref.watch(suppliersProvider);

    final works = worksAsync.value ?? [];
    final workers = workersAsync.value ?? [];
    final suppliers = suppliersAsync.value ?? [];

    final totalRevenue = works.fold(0.0, (s, w) => s + w.totalAmount);
    final totalCollected = works.fold(0.0, (s, w) => s + w.paidAmount);
    final totalRemaining = totalRevenue - totalCollected;
    final totalWorkerBalance = workers.fold(0.0, (s, w) => s + w.balance);
    final totalSupplierDebt = suppliers.fold(0.0, (s, sp) => s + sp.remaining);
    final netProfit = totalCollected - totalWorkerBalance - totalSupplierDebt;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('التدفق النقدي 💰')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          // Net profit card
          Container(
            padding: const EdgeInsets.all(AppSpacing.xl),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.teal, AppColors.teal2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: AppRadius.large,
              boxShadow: [
                BoxShadow(
                  color: AppColors.teal.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              children: [
                const Text('💎', style: TextStyle(fontSize: 32)),
                const SizedBox(height: 8),
                const Text(
                  'صافي الربح التقديري',
                  style: TextStyle(fontFamily: 'Cairo', color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 6),
                Text(
                  '${fmtAmount(netProfit)} ريال',
                  style: const TextStyle(
                    fontFamily: 'Tajawal',
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: AppSpacing.xl),

          // Revenue section
          _SectionTitle(title: 'الإيرادات 📈', color: AppColors.teal),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              Expanded(child: SummaryCard(label: 'إجمالي العقود', value: '${fmtAmount(totalRevenue)} ر', icon: '📋', color: AppColors.teal)),
              const SizedBox(width: AppSpacing.md),
              Expanded(child: SummaryCard(label: 'تم تحصيله', value: '${fmtAmount(totalCollected)} ر', icon: '✅', color: AppColors.green)),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          AppCard(
            child: Column(
              children: [
                StatRow(label: 'المتبقي من العملاء', value: '${fmtAmount(totalRemaining)} ر', valueColor: AppColors.gold),
                const SizedBox(height: 6),
                AppProgressBar(
                  value: totalRevenue > 0 ? totalCollected / totalRevenue : 0,
                  color: AppColors.green,
                ),
              ],
            ),
          ),

          const SizedBox(height: AppSpacing.lg),

          // Expenses section
          _SectionTitle(title: 'المصروفات 📉', color: AppColors.red),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              Expanded(child: SummaryCard(label: 'مستحقات العمال', value: '${fmtAmount(totalWorkerBalance)} ر', icon: '👷', color: AppColors.orange)),
              const SizedBox(width: AppSpacing.md),
              Expanded(child: SummaryCard(label: 'ديون الموردين', value: '${fmtAmount(totalSupplierDebt)} ر', icon: '🏭', color: AppColors.red)),
            ],
          ),

          const SizedBox(height: AppSpacing.xl),

          // Works breakdown
          _SectionTitle(title: 'تفصيل الأعمال', color: AppColors.blue),
          const SizedBox(height: AppSpacing.md),
          ...works.map((w) => Padding(
            padding: const EdgeInsets.only(bottom: AppSpacing.md),
            child: AppCard(
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(w.title, style: AppTextStyles.title),
                            Text(w.clientName, style: AppTextStyles.caption),
                          ],
                        ),
                      ),
                      StatusBadge(
                        label: w.statusLabel,
                        color: w.status == 'done' ? AppColors.green : AppColors.blue,
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  StatRow(label: 'الإجمالي', value: '${fmtAmount(w.totalAmount)} ر', valueColor: AppColors.teal),
                  StatRow(label: 'المحصّل', value: '${fmtAmount(w.paidAmount)} ر', valueColor: AppColors.green),
                  StatRow(label: 'المتبقي', value: '${fmtAmount(w.remaining)} ر', valueColor: w.remaining > 0 ? AppColors.red : AppColors.green),
                  const SizedBox(height: AppSpacing.sm),
                  AppProgressBar(value: w.progressPct),
                ],
              ),
            ),
          )),

          if (works.isEmpty)
            const EmptyState(emoji: '💰', message: 'لا توجد أعمال مسجلة بعد'),

          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final Color color;
  const _SectionTitle({required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 4, height: 18, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 8),
        Text(title, style: AppTextStyles.headline3),
      ],
    );
  }
}
