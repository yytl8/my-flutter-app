// Supplier detail screen is implemented inside suppliers_screen.dart
export 'suppliers_screen.dart' show SupplierDetailScreen;
