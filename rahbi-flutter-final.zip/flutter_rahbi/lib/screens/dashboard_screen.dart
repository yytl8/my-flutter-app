import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../widgets/common_widgets.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final shop = auth.shop;
    final user = auth.user;

    final clientsAsync = ref.watch(clientsProvider);
    final worksAsync = ref.watch(worksProvider);
    final workersAsync = ref.watch(workersProvider);
    final suppliersAsync = ref.watch(suppliersProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            floating: true,
            backgroundColor: AppColors.surface,
            elevation: 0,
            pinned: true,
            toolbarHeight: 64,
            title: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.teal, AppColors.teal2],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(child: Text('🪵', style: TextStyle(fontSize: 18))),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(shop?.name ?? 'الرحبي للنجارة', style: AppTextStyles.title),
                    Text('مرحباً، ${user?.name ?? ''}', style: AppTextStyles.caption),
                  ],
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => context.go('/settings'),
              ),
            ],
            bottom: const PreferredSize(
              preferredSize: Size.fromHeight(1),
              child: Divider(height: 1),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // ── Stats Grid ──
                worksAsync.when(
                  data: (works) {
                    final totalRevenue = works.fold(0.0, (s, w) => s + w.totalAmount);
                    final totalPaid = works.fold(0.0, (s, w) => s + w.paidAmount);
                    final remaining = totalRevenue - totalPaid;
                    final inProgress = works.where((w) => w.status == 'inProgress').length;

                    return Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: SummaryCard(
                                label: 'إجمالي الأعمال',
                                value: '${fmtAmount(totalRevenue)} ر',
                                icon: '💰',
                                color: AppColors.teal,
                              ),
                            ),
                            const SizedBox(width: AppSpacing.md),
                            Expanded(
                              child: SummaryCard(
                                label: 'المحصّل',
                                value: '${fmtAmount(totalPaid)} ر',
                                icon: '✅',
                                color: AppColors.green,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.md),
                        Row(
                          children: [
                            Expanded(
                              child: SummaryCard(
                                label: 'المتبقي',
                                value: '${fmtAmount(remaining)} ر',
                                icon: '⏳',
                                color: AppColors.gold,
                              ),
                            ),
                            const SizedBox(width: AppSpacing.md),
                            Expanded(
                              child: SummaryCard(
                                label: 'جاري التنفيذ',
                                value: '$inProgress مشروع',
                                icon: '🔨',
                                color: AppColors.blue,
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                  loading: () => const SizedBox(height: 120, child: Center(child: CircularProgressIndicator())),
                  error: (_, __) => const SizedBox.shrink(),
                ),

                const SizedBox(height: AppSpacing.xl),

                // ── Quick Actions ──
                Text('الوصول السريع', style: AppTextStyles.headline3),
                const SizedBox(height: AppSpacing.md),
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  mainAxisSpacing: AppSpacing.md,
                  crossAxisSpacing: AppSpacing.md,
                  childAspectRatio: 1.4,
                  children: [
                    _QuickAction(
                      icon: '👥',
                      label: 'العملاء',
                      color: AppColors.teal,
                      count: clientsAsync.value?.length,
                      onTap: () => context.go('/clients'),
                    ),
                    _QuickAction(
                      icon: '👷',
                      label: 'العمال',
                      color: AppColors.green,
                      count: workersAsync.value?.length,
                      onTap: () => context.go('/workers'),
                    ),
                    _QuickAction(
                      icon: '🏭',
                      label: 'الموردون',
                      color: AppColors.gold,
                      count: suppliersAsync.value?.length,
                      onTap: () => context.go('/suppliers'),
                    ),
                    _QuickAction(
                      icon: '🤖',
                      label: 'محلل AI',
                      color: AppColors.purple,
                      onTap: () => context.go('/ai-analyzer'),
                    ),
                  ],
                ),

                const SizedBox(height: AppSpacing.xl),

                // ── Recent Works ──
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('أحدث الأعمال', style: AppTextStyles.headline3),
                    TextButton(
                      onPressed: () => context.go('/clients'),
                      child: const Text('عرض الكل'),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                worksAsync.when(
                  data: (works) {
                    final recent = works.take(5).toList();
                    if (recent.isEmpty) {
                      return const EmptyState(
                        emoji: '🔨',
                        message: 'لا توجد أعمال بعد',
                        sub: 'أضف أول مشروع لعميل',
                      );
                    }
                    return Column(
                      children: recent.map((w) => _WorkCard(work: w)).toList(),
                    );
                  },
                  loading: () => const LoadingList(count: 3),
                  error: (e, _) => Text('خطأ: $e'),
                ),

                const SizedBox(height: 80),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final String icon;
  final String label;
  final Color color;
  final int? count;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
    this.count,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(child: Text(icon, style: const TextStyle(fontSize: 18))),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (count != null)
                Text(
                  '$count',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
              Text(label, style: AppTextStyles.caption),
            ],
          ),
        ],
      ),
    );
  }
}

class _WorkCard extends StatelessWidget {
  final dynamic work;
  const _WorkCard({required this.work});

  Color get _statusColor {
    switch (work.status) {
      case 'done': return AppColors.green;
      case 'inProgress': return AppColors.blue;
      case 'delivered': return AppColors.teal;
      default: return AppColors.gold;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(work.title, style: AppTextStyles.title),
                      Text(work.clientName, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                StatusBadge(label: work.statusLabel, color: _statusColor),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: [
                Text(
                  '${fmtAmount(work.totalAmount)} ر',
                  style: AppTextStyles.amount.copyWith(color: AppColors.teal, fontSize: 14),
                ),
                const SizedBox(width: 6),
                Text('•', style: AppTextStyles.caption),
                const SizedBox(width: 6),
                Text(
                  'متبقي: ${fmtAmount(work.remaining)} ر',
                  style: AppTextStyles.caption.copyWith(
                    color: work.remaining > 0 ? AppColors.red : AppColors.green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            AppProgressBar(value: work.progressPct, color: _statusColor),
          ],
        ),
      ),
    );
  }
}
