import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

// ══════════════════════════════════════════
// 🏪 Shop Select Screen
// ══════════════════════════════════════════
class ShopSelectScreen extends ConsumerWidget {
  const ShopSelectScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).user!;
    final shopsAsync = ref.watch(allShopsProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(AppSpacing.xl),
              child: Column(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.teal, AppColors.teal2],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.teal.withOpacity(0.3),
                          blurRadius: 16,
                        ),
                      ],
                    ),
                    child: const Center(child: Text('🏪', style: TextStyle(fontSize: 28))),
                  ),
                  const SizedBox(height: 12),
                  Text('اختر المحل', style: AppTextStyles.headline2),
                  const SizedBox(height: 4),
                  Text(
                    'مرحباً ${user.name}',
                    style: AppTextStyles.caption,
                  ),
                ],
              ),
            ),

            Expanded(
              child: shopsAsync.when(
                data: (shops) => shops.isEmpty
                    ? const EmptyState(emoji: '🏪', message: 'لا توجد محلات بعد')
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
                        itemCount: shops.length,
                        itemBuilder: (_, i) => _ShopCard(shop: shops[i]),
                      ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('خطأ: $e')),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(AppSpacing.xl),
              child: TextButton.icon(
                onPressed: () => ref.read(authProvider.notifier).logout(),
                icon: const Icon(Icons.logout, size: 16),
                label: const Text('تسجيل الخروج'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShopCard extends ConsumerWidget {
  final Shop shop;
  const _ShopCard({required this.shop});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final color = AppColors.entityColor(shop.id);
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: AppCard(
        onTap: () => ref.read(authProvider.notifier).selectShop(shop),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  shop.name.isNotEmpty ? shop.name[0] : '🏪',
                  style: TextStyle(fontSize: 22, color: color, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(shop.name, style: AppTextStyles.title),
                  if (shop.address != null)
                    Text(shop.address!, style: AppTextStyles.caption),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: AppColors.text3),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// 🏠 Main Shell — Admin Bottom Nav
// ══════════════════════════════════════════
class MainShell extends ConsumerStatefulWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _selectedIndex = 0;

  static const _routes = [
    '/home',
    '/clients',
    '/workers',
    '/suppliers',
    '/ai-analyzer',
  ];

  static const _navItems = [
    BottomNavigationBarItem(icon: Text('🏠', style: TextStyle(fontSize: 20)), label: 'الرئيسية'),
    BottomNavigationBarItem(icon: Text('👥', style: TextStyle(fontSize: 20)), label: 'العملاء'),
    BottomNavigationBarItem(icon: Text('👷', style: TextStyle(fontSize: 20)), label: 'العمال'),
    BottomNavigationBarItem(icon: Text('🏭', style: TextStyle(fontSize: 20)), label: 'الموردون'),
    BottomNavigationBarItem(icon: Text('🤖', style: TextStyle(fontSize: 20)), label: 'محلل AI'),
  ];

  @override
  Widget build(BuildContext context) {
    final shop = ref.watch(authProvider).shop;

    return Scaffold(
      body: widget.child,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: const Border(top: BorderSide(color: AppColors.border)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: BottomNavigationBar(
            currentIndex: _selectedIndex,
            items: _navItems,
            onTap: (i) {
              setState(() => _selectedIndex = i);
              context.go(_routes[i]);
            },
            elevation: 0,
            backgroundColor: Colors.transparent,
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════
// 👷 Worker Portal Shell
// ══════════════════════════════════════════
class WorkerPortalShell extends ConsumerStatefulWidget {
  final Widget child;
  const WorkerPortalShell({super.key, required this.child});

  @override
  ConsumerState<WorkerPortalShell> createState() => _WorkerPortalShellState();
}

class _WorkerPortalShellState extends ConsumerState<WorkerPortalShell> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: widget.child);
  }
}
