import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../core/theme.dart';
import '../core/providers.dart';
import '../models/models.dart';
import '../widgets/common_widgets.dart';

// ══════════════════════════════════════════
// 👷 Worker Portal Screen
// ══════════════════════════════════════════
class WorkerPortalScreen extends ConsumerStatefulWidget {
  const WorkerPortalScreen({super.key});

  @override
  ConsumerState<WorkerPortalScreen> createState() => _WorkerPortalScreenState();
}

class _WorkerPortalScreenState extends ConsumerState<WorkerPortalScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authProvider);
    final user = auth.user;
    final workersAsync = ref.watch(workersProvider);

    // Find this user's worker record
    final worker = workersAsync.value?.firstWhere(
      (w) => w.id == user?.id || w.phone == user?.phone,
      orElse: () => Worker(id: '', shopId: '', name: user?.name ?? ''),
    );

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: AppColors.teal,
            foregroundColor: Colors.white,
            pinned: true,
            expandedHeight: 180,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.teal, AppColors.teal2],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSpacing.xl),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Text('👋', style: TextStyle(fontSize: 30)),
                        const SizedBox(height: 4),
                        Text(
                          'مرحباً، ${user?.name ?? ''}',
                          style: const TextStyle(
                            fontFamily: 'Tajawal',
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 6),
                        if (worker != null)
                          Row(
                            children: [
                              _StatPill('المكتسب', '${fmtAmount(worker.totalEarned)} ر'),
                              const SizedBox(width: 8),
                              _StatPill('المسحوب', '${fmtAmount(worker.totalWithdrawn)} ر'),
                              const SizedBox(width: 8),
                              _StatPill('الرصيد', '${fmtAmount(worker.balance)} ر'),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.logout),
                onPressed: () => _confirmLogout(context),
                tooltip: 'تسجيل الخروج',
              ),
            ],
            bottom: TabBar(
              controller: _tabs,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white54,
              indicatorColor: Colors.white,
              tabs: const [
                Tab(text: 'أعمالي'),
                Tab(text: 'سحوباتي'),
                Tab(text: 'طلب سحب'),
              ],
            ),
          ),

          SliverFillRemaining(
            child: TabBarView(
              controller: _tabs,
              children: [
                _WorkerJobs(worker: worker),
                _WorkerWithdrawals(worker: worker),
                _WorkerRequestWithdrawal(worker: worker),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل أنت متأكد؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ref.read(authProvider.notifier).logout();
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.red),
            child: const Text('خروج'),
          ),
        ],
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  final String label;
  final String value;
  const _StatPill(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(value, style: const TextStyle(fontFamily: 'Cairo', color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
          Text(label, style: const TextStyle(fontFamily: 'Cairo', color: Colors.white70, fontSize: 10)),
        ],
      ),
    );
  }
}

class _WorkerJobs extends StatelessWidget {
  final Worker? worker;
  const _WorkerJobs({this.worker});

  @override
  Widget build(BuildContext context) {
    final jobs = worker?.jobs ?? [];
    if (jobs.isEmpty) {
      return const EmptyState(emoji: '🔨', message: 'لا توجد أعمال مسجلة بعد');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: jobs.length,
      itemBuilder: (_, i) {
        final job = jobs[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: AppCard(
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: job.status == 'approved' ? AppColors.greenLight : AppColors.goldLight,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      job.status == 'approved' ? '✅' : '⏳',
                      style: const TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(job.title, style: AppTextStyles.title),
                      Text(job.date, style: AppTextStyles.caption),
                      if (job.notes != null) Text(job.notes!, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${fmtAmount(job.amount)} ر',
                      style: AppTextStyles.bodyMedium.copyWith(color: AppColors.teal),
                    ),
                    StatusBadge(
                      label: job.status == 'approved' ? 'معتمد' : 'قيد المراجعة',
                      color: job.status == 'approved' ? AppColors.green : AppColors.gold,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _WorkerWithdrawals extends StatelessWidget {
  final Worker? worker;
  const _WorkerWithdrawals({this.worker});

  @override
  Widget build(BuildContext context) {
    final withdrawals = worker?.withdrawals ?? [];
    if (withdrawals.isEmpty) {
      return const EmptyState(emoji: '💵', message: 'لا توجد سحوبات بعد');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: withdrawals.length,
      itemBuilder: (_, i) {
        final w = withdrawals[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: AppCard(
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.redLight,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(child: Text('💵', style: TextStyle(fontSize: 18))),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(w.note ?? 'سحب نقدي', style: AppTextStyles.title),
                      Text(w.date, style: AppTextStyles.caption),
                    ],
                  ),
                ),
                Text(
                  '${fmtAmount(w.amount)} ر',
                  style: AppTextStyles.bodyMedium.copyWith(color: AppColors.red),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _WorkerRequestWithdrawal extends ConsumerStatefulWidget {
  final Worker? worker;
  const _WorkerRequestWithdrawal({this.worker});

  @override
  ConsumerState<_WorkerRequestWithdrawal> createState() => _WorkerRequestWithdrawalState();
}

class _WorkerRequestWithdrawalState extends ConsumerState<_WorkerRequestWithdrawal> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _form = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (widget.worker == null) return;

    setState(() => _loading = true);

    final shopId = ref.read(shopIdProvider);
    if (shopId == null) return;

    final amt = double.tryParse(_amount.text) ?? 0;
    final now = DateTime.now();
    final dateStr = '${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}';

    final workerRef = FirebaseFirestore.instance
        .collection('shops')
        .doc(shopId)
        .collection('workers')
        .doc(widget.worker!.id);

    final newWithdrawal = {
      'id': const Uuid().v4(),
      'amount': amt,
      'note': _note.text.trim().isEmpty ? 'طلب سحب من العامل' : _note.text.trim(),
      'date': dateStr,
      'status': 'pending',
    };

    final updatedWithdrawals = [...widget.worker!.withdrawals.map((w) => w.toMap()), newWithdrawal];
    await workerRef.update({'withdrawals': updatedWithdrawals});

    if (mounted) {
      setState(() => _loading = false);
      _amount.clear();
      _note.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تم إرسال طلب السحب للمراجعة')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final balance = widget.worker?.balance ?? 0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSpacing.xl),
      child: Form(
        key: _form,
        child: Column(
          children: [
            // Balance display
            AppCard(
              color: AppColors.goldLight,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('💰', style: TextStyle(fontSize: 28)),
                  const SizedBox(width: 12),
                  Column(
                    children: [
                      Text(
                        '${fmtAmount(balance)} ريال',
                        style: const TextStyle(
                          fontFamily: 'Tajawal',
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          color: AppColors.gold,
                        ),
                      ),
                      Text('رصيدك الحالي', style: AppTextStyles.caption),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: AppSpacing.xl),

            AppFormField(
              label: 'المبلغ المطلوب (ر.س)',
              hint: '0',
              controller: _amount,
              keyboardType: TextInputType.number,
              validator: (v) {
                if (v?.isEmpty == true) return 'أدخل المبلغ';
                final amt = double.tryParse(v!) ?? 0;
                if (amt <= 0) return 'المبلغ يجب أن يكون أكبر من صفر';
                if (amt > balance) return 'المبلغ أكبر من رصيدك';
                return null;
              },
            ),

            const SizedBox(height: AppSpacing.md),

            AppFormField(
              label: 'ملاحظة (اختياري)',
              hint: 'سبب السحب...',
              controller: _note,
              maxLines: 2,
            ),

            const SizedBox(height: AppSpacing.xl),

            PrimaryButton(
              label: 'إرسال طلب السحب',
              icon: '📤',
              onTap: _submit,
              isLoading: _loading,
              color: AppColors.gold,
            ),

            const SizedBox(height: AppSpacing.lg),

            Text(
              'سيتم مراجعة طلبك من قِبل المدير وإشعارك بالقرار',
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
