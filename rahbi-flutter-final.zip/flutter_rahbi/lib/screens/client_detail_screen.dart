// Client detail is implemented inside clients_screen.dart
export 'clients_screen.dart' show ClientDetailScreen;
