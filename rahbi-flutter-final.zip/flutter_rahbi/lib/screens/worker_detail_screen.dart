// Worker detail screen is implemented inside workers_screen.dart
// This file re-exports it for router compatibility
export 'workers_screen.dart' show WorkerDetailScreen;
