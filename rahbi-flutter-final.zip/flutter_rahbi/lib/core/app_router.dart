import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../screens/splash_screen.dart';
import '../screens/auth_screen.dart';
import '../screens/shop_select_screen.dart';
import '../screens/main_shell.dart';
import '../screens/dashboard_screen.dart';
import '../screens/clients_screen.dart';
import '../screens/client_detail_screen.dart';
import '../screens/workers_screen.dart';
import '../screens/worker_detail_screen.dart';
import '../screens/suppliers_screen.dart';
import '../screens/supplier_detail_screen.dart';
import '../screens/ai_analyzer_screen.dart';
import '../screens/cashflow_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/worker_portal_screen.dart';
import 'providers.dart';

// ══════════════════════════════════════════
// 🗺️ App Routes
// ══════════════════════════════════════════
GoRouter createRouter(Ref ref) {
  final authNotifier = ref.watch(authProvider.notifier);

  return GoRouter(
    initialLocation: '/splash',
    refreshListenable: RouterNotifier(ref),
    redirect: (context, state) {
      final authState = ref.read(authProvider);
      final isLoading = authState.isLoading;
      final isLoggedIn = authState.isLoggedIn;
      final hasShop = authState.hasShop;
      final path = state.matchedLocation;

      if (isLoading) return '/splash';

      if (!isLoggedIn) {
        if (path != '/auth') return '/auth';
        return null;
      }

      if (isLoggedIn && !hasShop) {
        if (path != '/shop-select') return '/shop-select';
        return null;
      }

      if (path == '/splash' || path == '/auth' || path == '/shop-select') {
        final user = authState.user!;
        if (user.isWorker) return '/worker';
        return '/home';
      }

      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
      GoRoute(path: '/auth', builder: (_, __) => const AuthScreen()),
      GoRoute(path: '/shop-select', builder: (_, __) => const ShopSelectScreen()),

      // Worker Portal
      ShellRoute(
        builder: (context, state, child) => WorkerPortalShell(child: child),
        routes: [
          GoRoute(path: '/worker', builder: (_, __) => const WorkerPortalScreen()),
        ],
      ),

      // Main Admin Shell
      ShellRoute(
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          GoRoute(path: '/home', builder: (_, __) => const DashboardScreen()),
          GoRoute(
            path: '/clients',
            builder: (_, __) => const ClientsScreen(),
            routes: [
              GoRoute(
                path: ':id',
                builder: (_, state) => ClientDetailScreen(id: state.pathParameters['id']!),
              ),
            ],
          ),
          GoRoute(
            path: '/workers',
            builder: (_, __) => const WorkersScreen(),
            routes: [
              GoRoute(
                path: ':id',
                builder: (_, state) => WorkerDetailScreen(id: state.pathParameters['id']!),
              ),
            ],
          ),
          GoRoute(
            path: '/suppliers',
            builder: (_, __) => const SuppliersScreen(),
            routes: [
              GoRoute(
                path: ':id',
                builder: (_, state) => SupplierDetailScreen(id: state.pathParameters['id']!),
              ),
            ],
          ),
          GoRoute(path: '/ai-analyzer', builder: (_, __) => const AIAnalyzerScreen()),
          GoRoute(path: '/cashflow', builder: (_, __) => const CashflowScreen()),
          GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
        ],
      ),
    ],
  );
}

class RouterNotifier extends ChangeNotifier {
  final Ref _ref;
  RouterNotifier(this._ref) {
    _ref.listen(authProvider, (_, __) => notifyListeners());
  }
}
