import 'package:flutter/material.dart';

// ══════════════════════════════════════════
// 🎨 نظام الألوان — مطابق للـ CSS Variables في PWA
// ══════════════════════════════════════════
class AppColors {
  // Primary — Indigo
  static const Color teal = Color(0xFF4F46E5);
  static const Color teal2 = Color(0xFF3730A3);
  static const Color teal3 = Color(0xFF1E1B72);
  static const Color tealLight = Color(0xFFEEF0FF);
  static const Color tealPale = Color(0xFFC7D2FE);

  // Semantic
  static const Color gold = Color(0xFFD97706);
  static const Color goldLight = Color(0xFFFEF3C7);
  static const Color green = Color(0xFF059669);
  static const Color greenLight = Color(0xFFECFDF5);
  static const Color red = Color(0xFFDC2626);
  static const Color redLight = Color(0xFFFEF2F2);
  static const Color blue = Color(0xFF2563EB);
  static const Color blueLight = Color(0xFFEFF6FF);
  static const Color purple = Color(0xFF7C3AED);
  static const Color purpleLight = Color(0xFFF5F3FF);
  static const Color orange = Color(0xFFEA580C);
  static const Color orangeLight = Color(0xFFFFF7ED);

  // Backgrounds
  static const Color bg = Color(0xFFF0F2FA);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surface2 = Color(0xFFF7F8FD);
  static const Color surface3 = Color(0xFFEEF0FC);

  // Borders
  static const Color border = Color(0xFFDDE2F4);
  static const Color border2 = Color(0xFFC4CCE8);

  // Text
  static const Color text = Color(0xFF0F172A);
  static const Color text2 = Color(0xFF475569);
  static const Color text3 = Color(0xFF94A3B8);

  // Card colors for entities
  static const List<Color> entityColors = [
    Color(0xFF4F46E5),
    Color(0xFF059669),
    Color(0xFFD97706),
    Color(0xFFDC2626),
    Color(0xFF7C3AED),
    Color(0xFF2563EB),
    Color(0xFFEA580C),
    Color(0xFF0891B2),
  ];

  static Color entityColor(String id) {
    final hash = id.codeUnits.fold(0, (a, b) => a + b);
    return entityColors[hash % entityColors.length];
  }
}

// ══════════════════════════════════════════
// 📐 Border Radius & Spacing
// ══════════════════════════════════════════
class AppRadius {
  static const double sm = 10.0;
  static const double md = 14.0;
  static const double lg = 20.0;
  static const double xl = 24.0;

  static BorderRadius get small => BorderRadius.circular(sm);
  static BorderRadius get medium => BorderRadius.circular(md);
  static BorderRadius get large => BorderRadius.circular(lg);
  static BorderRadius get xlarge => BorderRadius.circular(xl);
}

class AppSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 12.0;
  static const double lg = 16.0;
  static const double xl = 20.0;
  static const double xxl = 24.0;
  static const double xxxl = 32.0;
}

// ══════════════════════════════════════════
// 🌟 Text Styles
// ══════════════════════════════════════════
class AppTextStyles {
  static const String cairoFamily = 'Cairo';
  static const String tajawalFamily = 'Tajawal';

  static TextStyle headline1 = const TextStyle(
    fontFamily: tajawalFamily,
    fontSize: 28,
    fontWeight: FontWeight.w900,
    color: AppColors.teal2,
  );

  static TextStyle headline2 = const TextStyle(
    fontFamily: tajawalFamily,
    fontSize: 22,
    fontWeight: FontWeight.w800,
    color: AppColors.text,
  );

  static TextStyle headline3 = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 18,
    fontWeight: FontWeight.w700,
    color: AppColors.text,
  );

  static TextStyle title = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 15,
    fontWeight: FontWeight.w700,
    color: AppColors.text,
  );

  static TextStyle body = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: AppColors.text,
  );

  static TextStyle bodyMedium = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: AppColors.text,
  );

  static TextStyle caption = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: AppColors.text2,
  );

  static TextStyle label = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 11,
    fontWeight: FontWeight.w700,
    color: AppColors.text3,
    letterSpacing: 0.3,
  );

  static TextStyle amount = const TextStyle(
    fontFamily: cairoFamily,
    fontSize: 16,
    fontWeight: FontWeight.w700,
    color: AppColors.text,
  );
}

// ══════════════════════════════════════════
// 🎨 Material Theme
// ══════════════════════════════════════════
class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Cairo',
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.teal,
        brightness: Brightness.light,
        primary: AppColors.teal,
        secondary: AppColors.teal2,
        background: AppColors.bg,
        surface: AppColors.surface,
        error: AppColors.red,
        onPrimary: Colors.white,
        onBackground: AppColors.text,
        onSurface: AppColors.text,
      ),
      scaffoldBackgroundColor: AppColors.bg,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.text,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 17,
          fontWeight: FontWeight.w700,
          color: AppColors.text,
        ),
        iconTheme: IconThemeData(color: AppColors.text),
      ),
      cardTheme: CardTheme(
        color: AppColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: AppRadius.medium,
          side: const BorderSide(color: AppColors.border, width: 1),
        ),
        margin: const EdgeInsets.only(bottom: AppSpacing.md),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface2,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.lg,
          vertical: AppSpacing.md,
        ),
        border: OutlineInputBorder(
          borderRadius: AppRadius.small,
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: AppRadius.small,
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: AppRadius.small,
          borderSide: const BorderSide(color: AppColors.teal, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: AppRadius.small,
          borderSide: const BorderSide(color: AppColors.red),
        ),
        labelStyle: const TextStyle(
          fontFamily: 'Cairo',
          color: AppColors.text2,
          fontSize: 13,
        ),
        hintStyle: const TextStyle(
          fontFamily: 'Cairo',
          color: AppColors.text3,
          fontSize: 13,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.teal,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.xl,
            vertical: AppSpacing.md,
          ),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
          textStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.teal,
          textStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.teal,
          side: const BorderSide(color: AppColors.teal),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
          textStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.teal,
        unselectedItemColor: AppColors.text3,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
        unselectedLabelStyle: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 11,
          fontWeight: FontWeight.w400,
        ),
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.border,
        thickness: 1,
        space: 0,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.surface2,
        selectedColor: AppColors.tealLight,
        labelStyle: const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
        side: const BorderSide(color: AppColors.border),
      ),
      tabBarTheme: const TabBarTheme(
        labelColor: AppColors.teal,
        unselectedLabelColor: AppColors.text3,
        indicatorColor: AppColors.teal,
        labelStyle: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 13,
          fontWeight: FontWeight.w700,
        ),
        unselectedLabelStyle: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.text,
        contentTextStyle: const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
        shape: RoundedRectangleBorder(borderRadius: AppRadius.small),
      ),
      dialogTheme: DialogTheme(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.large),
        titleTextStyle: const TextStyle(
          fontFamily: 'Tajawal',
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: AppColors.text,
        ),
        contentTextStyle: const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 13,
          color: AppColors.text2,
        ),
      ),
    );
  }

  static ThemeData get darkTheme => lightTheme; // يمكن تطوير الوضع الليلي لاحقاً
}
