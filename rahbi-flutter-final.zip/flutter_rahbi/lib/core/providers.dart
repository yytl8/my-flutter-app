import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:go_router/go_router.dart';

import '../models/models.dart';
import 'app_router.dart';

// ══════════════════════════════════════════
// 🔑 Auth State
// ══════════════════════════════════════════
class AuthState {
  final AppUser? user;
  final Shop? shop;
  final bool isLoading;
  final String? error;

  const AuthState({
    this.user,
    this.shop,
    this.isLoading = false,
    this.error,
  });

  bool get isLoggedIn => user != null;
  bool get hasShop => shop != null;

  AuthState copyWith({
    AppUser? user,
    Shop? shop,
    bool? isLoading,
    String? error,
    bool clearUser = false,
    bool clearShop = false,
  }) {
    return AuthState(
      user: clearUser ? null : (user ?? this.user),
      shop: clearShop ? null : (shop ?? this.shop),
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }
}

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier() : super(const AuthState(isLoading: true)) {
    _init();
  }

  Future<void> _init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString('userId');
      final shopId = prefs.getString('shopId');

      if (userId != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .get();

        if (userDoc.exists) {
          final user = AppUser.fromFirestore(userDoc);
          Shop? shop;

          if (shopId != null) {
            final shopDoc = await FirebaseFirestore.instance
                .collection('shops')
                .doc(shopId)
                .get();
            if (shopDoc.exists) {
              shop = Shop.fromFirestore(shopDoc);
            }
          }

          state = AuthState(user: user, shop: shop, isLoading: false);
          return;
        }
      }
    } catch (e) {
      // continue to login
    }
    state = const AuthState(isLoading: false);
  }

  Future<String?> login(String email, String password) async {
    state = state.copyWith(isLoading: true);
    try {
      final q = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email.trim().toLowerCase())
          .where('password', isEqualTo: password)
          .limit(1)
          .get();

      if (q.docs.isEmpty) {
        state = state.copyWith(isLoading: false, error: 'بيانات الدخول غير صحيحة');
        return 'بيانات الدخول غير صحيحة';
      }

      final user = AppUser.fromFirestore(q.docs.first);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('userId', user.id);

      state = AuthState(user: user, isLoading: false);
      return null;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return e.toString();
    }
  }

  Future<String?> register({
    required String name,
    required String email,
    required String password,
    required String shopName,
    String? phone,
  }) async {
    state = state.copyWith(isLoading: true);
    try {
      // Check if email exists
      final existing = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email.trim().toLowerCase())
          .limit(1)
          .get();

      if (existing.docs.isNotEmpty) {
        state = state.copyWith(isLoading: false, error: 'البريد الإلكتروني مستخدم مسبقاً');
        return 'البريد الإلكتروني مستخدم مسبقاً';
      }

      // Create shop
      final shopRef = await FirebaseFirestore.instance.collection('shops').add({
        'name': shopName,
        'isActive': true,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Create user
      final userRef = await FirebaseFirestore.instance.collection('users').add({
        'name': name,
        'email': email.trim().toLowerCase(),
        'password': password,
        'role': 'admin',
        'shopId': shopRef.id,
        'phone': phone,
        'permissions': {},
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Update shop with ownerId
      await shopRef.update({'ownerId': userRef.id});

      final userDoc = await userRef.get();
      final shopDoc = await shopRef.get();
      final user = AppUser.fromFirestore(userDoc);
      final shop = Shop.fromFirestore(shopDoc);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('userId', user.id);
      await prefs.setString('shopId', shop.id);

      state = AuthState(user: user, shop: shop, isLoading: false);
      return null;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return e.toString();
    }
  }

  Future<void> selectShop(Shop shop) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shopId', shop.id);
    state = state.copyWith(shop: shop);
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('userId');
    await prefs.remove('shopId');
    state = const AuthState();
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(),
);

// ══════════════════════════════════════════
// 📦 Data Providers
// ══════════════════════════════════════════
final shopIdProvider = Provider<String?>((ref) {
  return ref.watch(authProvider).shop?.id;
});

final clientsProvider = StreamProvider<List<Client>>((ref) {
  final shopId = ref.watch(shopIdProvider);
  if (shopId == null) return Stream.value([]);

  return FirebaseFirestore.instance
      .collection('shops')
      .doc(shopId)
      .collection('clients')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Client.fromFirestore(d)).toList());
});

final worksProvider = StreamProvider<List<Work>>((ref) {
  final shopId = ref.watch(shopIdProvider);
  if (shopId == null) return Stream.value([]);

  return FirebaseFirestore.instance
      .collection('shops')
      .doc(shopId)
      .collection('works')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Work.fromFirestore(d)).toList());
});

final workersProvider = StreamProvider<List<Worker>>((ref) {
  final shopId = ref.watch(shopIdProvider);
  if (shopId == null) return Stream.value([]);

  return FirebaseFirestore.instance
      .collection('shops')
      .doc(shopId)
      .collection('workers')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Worker.fromFirestore(d)).toList());
});

final suppliersProvider = StreamProvider<List<Supplier>>((ref) {
  final shopId = ref.watch(shopIdProvider);
  if (shopId == null) return Stream.value([]);

  return FirebaseFirestore.instance
      .collection('shops')
      .doc(shopId)
      .collection('suppliers')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Supplier.fromFirestore(d)).toList());
});

// Super Admin — all shops
final allShopsProvider = StreamProvider<List<Shop>>((ref) {
  final user = ref.watch(authProvider).user;
  if (user == null || !user.isSuperAdmin) return Stream.value([]);

  return FirebaseFirestore.instance
      .collection('shops')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Shop.fromFirestore(d)).toList());
});

// Router provider
final appRouterProvider = Provider<GoRouter>((ref) => createRouter(ref));
