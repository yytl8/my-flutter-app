package com.mahali.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
